.. py:module:: PIL.ImageMorph
.. py:currentmodule:: PIL.ImageMorph

:py:mod:`~PIL.ImageMorph` Module
================================

The :py:mod:`~PIL.ImageMorph` module provides morphology operations on images.

.. automodule:: PIL.ImageMorph
    :members:
    :undoc-members:
    :show-inheritance:
    :noindex:
